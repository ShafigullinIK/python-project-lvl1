import prompt
import cli


def even_game():
    print('Answer "yes" if number even otherwise answer "no"', \n)
    counter = 0
    max_int = 100
    while counter < 3:
        number = random.randint(max_int)
        correct_answer = "yes"
        if number % 2 == 1:
            correct_answer = "no"
        answer = prompt.string('Question: {}'.format(number))
        if answer == correct_answer:
            print("Correct!")
            counter = counter + 1
        else:
            return false
    return true
