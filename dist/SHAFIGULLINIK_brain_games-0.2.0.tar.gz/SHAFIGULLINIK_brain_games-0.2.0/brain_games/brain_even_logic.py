import prompt
import even_game_questions as e_g_q
import cli


def game(game_name):
    counter = 0    
    while counter < 3:
        if game_name == "even_game":
            question_with_answer = e_g_q.create_question()
        elif game_name == "calc_game":
            question_with_answer = ""
        is_answer_correct = cli.ask_question(question_with_answer)
        if is_answer_correct is True:
            counter = counter + 1        
        else:            
            return False
    return True
